#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "CheckIn.h"
#include "Routing.h"
#include "Eviction.h"
#include "FuzzySearch.h"
#include "CheckOut.h"

int main() {
    Graph G; loadMapFromFile("map.txt", &G);
    HashTable HT; initHashTable(&HT);
    Queue Q; initQueue(&Q);
    PriorityQueue PQ; initPQ(&PQ, 50);
    Stack S; initStack(&S);

    int physicalCapacity = G.n - 1;
    int maxAllowed = physicalCapacity;

    int choice;
    do {
        printf("\n======= SMART CAMPUS PARKING =======\n");
        printf("Xe: %d | Gioi han SV: %d | Suc chua: %d\n",
               getCurrentCarCount(&HT), maxAllowed, physicalCapacity);
        printf("1. Nhap su kien thu cong (IN, OUT, FIND)\n");
        printf("2. Doi gioi han cho phep SV\n");
        printf("3. Di doi xe SV (khu GV)\n");
        printf("0. Thoat\nChon: ");
        scanf("%d", &choice);

        switch (choice) {
        case 1:
            runSimulationFromConsole(&HT, &Q, &G, &PQ, maxAllowed);
            break;
        case 2:
            printf("Gioi han mới (hien tai %d): ", maxAllowed);
            int v; scanf("%d", &v);
            if (v > 0) {
                maxAllowed = v; printf("OK!\n");
                while (!isEmptyQueue(&Q) && getCurrentCarCount(&HT) < maxAllowed) {
                    Xe x; DeQueue(&Q, &x);
                    printf(">> Goi xe %s tu Hang doi:\n", x.bienSo);
                    processCheckIn(x, &HT, &Q, &G, &PQ, maxAllowed);
                }
            }
            break;
        case 3:
            if (PQ.size > 0) findAndEvictStudent(&PQ, &S, &G, &HT);
            else printf("Khong co xe SV do ke khu GV!\n");
            break;
        }
    } while (choice != 0);
    return 0;
}