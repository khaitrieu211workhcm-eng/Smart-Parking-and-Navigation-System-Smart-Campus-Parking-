#define _CRT_SECURE_NO_WARNINGS
#include "Routing.h"
#include <stdio.h>
#include <stdlib.h>

void loadMapFromFile(char* filename, Graph* G) {
    FILE* f = fopen(filename, "rt");
    if (f == NULL) { printf("Loi mo file map %s!\n", filename); return; }
    fscanf(f, "%d", &G->n);
    for (int i = 0; i < G->n; i++) {
        fscanf(f, "%d", &G->zoneType[i]);
        G->isOccupied[i] = 0;
    }
    G->isOccupied[0] = 1; // Mac dinh cong luon lock
    for (int i = 0; i < G->n; i++) {
        for (int j = 0; j < G->n; j++) {
            fscanf(f, "%d", &G->matrix[i][j]);
        }
    }
    fclose(f);
}

int lastDijkstraPath[MAX_NODES];
int lastDijkstraPathLen = 0;

int* findNearestSlot(Graph* G, int startNode, int isGiangVien, int* pathLength) {
    int dist[MAX_NODES], visited[MAX_NODES], trace[MAX_NODES];
    for (int i = 0; i < G->n; i++) { dist[i] = INF; visited[i] = 0; trace[i] = -1; }
    dist[startNode] = 0;

    for (int count = 0; count < G->n - 1; count++) {
        int u = -1, min_dist = INF;
        for (int i = 0; i < G->n; i++) {
            if (!visited[i] && dist[i] < min_dist) { min_dist = dist[i]; u = i; }
        }
        if (u == -1) break;
        visited[u] = 1;
        for (int v = 0; v < G->n; v++) {
            if (G->matrix[u][v] != 0 && !visited[v] && dist[u] + G->matrix[u][v] < dist[v]) {
                dist[v] = dist[u] + G->matrix[u][v];
                trace[v] = u;
            }
        }
    }

    int target = -1, min_d = INF;
    for (int i = 1; i < G->n; i++) {
        if (G->isOccupied[i] == 0 && dist[i] < min_d) {
            if (isGiangVien == 1 || (isGiangVien == 0 && G->zoneType[i] == 0)) {
                target = i; min_d = dist[i];
            }
        }
    }

    if (target == -1 && isGiangVien == 0) {
        for (int i = 1; i < G->n; i++) {
            if (G->isOccupied[i] == 0 && G->zoneType[i] == 1 && dist[i] < min_d) {
                target = i; min_d = dist[i];
            }
        }
    }

    if (target == -1) {
        lastDijkstraPathLen = 0;
        return NULL;
    }

    int* path = (int*)malloc(MAX_NODES * sizeof(int));
    int curr = target, len = 0;
    while (curr != -1) { path[len++] = curr; curr = trace[curr]; }
    *pathLength = len;

    lastDijkstraPathLen = len;
    for (int i = 0; i < len; i++) lastDijkstraPath[i] = path[i];

    return path;
}

void printPath(int* path, int pathLength) {
    for (int i = pathLength - 1; i >= 0; i--) {
        if (path[i] == 0) printf("Cong");
        else printf("O_So_%d", path[i]);
        if (i > 0) printf(" -> ");
    }
    printf("\n");
}