#include "Eviction.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Tim kiem xe trong bang bam bang vi tri do
Xe* findCarAtSlot(HashTable* HT, int slot) {
    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT->buckets[i];
        while (curr != NULL) {
            if (curr->xe.viTriDo == slot) {
                return &(curr->xe);
            }
            curr = curr->next;
        }
    }
    return NULL;
}

Xe findAndEvictStudent(PriorityQueue* PQ, Stack* S, Graph* G, HashTable* HT) {
    Xe evictedXe;
    int found = 0;
    while (PQ->size > 0) {
        evictedXe = popPQ(PQ);
        Xe* check = searchHash(HT, evictedXe.maThe);
        if (check != NULL && check->viTriDo == evictedXe.viTriDo) {
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Khong co xe sinh vien hop le nao de di doi!\n");
        Xe empty = { 0 };
        return empty;
    }

    int targetSlot = evictedXe.viTriDo;
    printf(">> CANH BAO: Phat hien xe sinh vien %s tai o GV %d dang chiem cho. Tien hanh di doi!\n", evictedXe.bienSo, targetSlot);

    // Di doi tam thoi cac xe phia truoc (tu cong den targetSlot - 1)
    // Cong la 0, cac o do trong khu GV la 1, 2, ..., 100.
    // Vi du neu targetSlot = 5, cac o chan tu 1 den 4 se can di doi tam thoi.
    for (int j = 1; j < targetSlot; j++) {
        if (G->isOccupied[j]) {
            Xe* blockXe = findCarAtSlot(HT, j);
            if (blockXe != NULL) {
                printf("  [STACK] Di doi tam thoi xe %s tai o %d vao Stack\n", blockXe->bienSo, j);
                Push(S, *blockXe);
                G->isOccupied[j] = 0;
            }
        }
    }

    // Di doi xe muc tieu ra khoi bai
    printf("  [EVICT] Xe sinh vien %s da duoc di doi ra khoi o %d\n", evictedXe.bienSo, targetSlot);
    G->isOccupied[targetSlot] = 0;
    removeHash(HT, evictedXe.maThe);

    // Dua cac xe tu Stack tro lai vi tri cu
    while (!isEmptyStack(S)) {
        Xe restoreXe = Pop(S);
        G->isOccupied[restoreXe.viTriDo] = 1;
        printf("  [STACK] Tra xe %s tu Stack ve lai o %d\n", restoreXe.bienSo, restoreXe.viTriDo);
    }

    return evictedXe;
}