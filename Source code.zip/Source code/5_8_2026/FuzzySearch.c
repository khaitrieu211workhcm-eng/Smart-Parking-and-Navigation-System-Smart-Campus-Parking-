#include "FuzzySearch.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void normalizeString(char* src, char* dst) {
    int j = 0;
    for (int i = 0; src[i] != '\0'; i++) {
        if (src[i] != ' ' && src[i] != '-' && src[i] != '.') {
            dst[j++] = (src[i] >= 'a' && src[i] <= 'z') ? src[i] - 32 : src[i];
        }
    }
    dst[j] = '\0';
}

int getLevenshteinDistance(char* s1, char* s2) {
    int len1 = strlen(s1), len2 = strlen(s2);
    int dp[40][40];

    for (int i = 0; i <= len1; i++) dp[i][0] = i;
    for (int j = 0; j <= len2; j++) dp[0][j] = j;

    for (int i = 1; i <= len1; i++) {
        for (int j = 1; j <= len2; j++) {
            if (s1[i - 1] == s2[j - 1]) dp[i][j] = dp[i - 1][j - 1];
            else {
                int min = dp[i - 1][j] < dp[i][j - 1] ? dp[i - 1][j] : dp[i][j - 1];
                dp[i][j] = 1 + (min < dp[i - 1][j - 1] ? min : dp[i - 1][j - 1]);
            }
        }
    }
    return dp[len1][len2];
}

Xe* fuzzySearchLicensePlate(HashTable* HT, char* queryPlate, int* resultCount) {
    char normQuery[50]; normalizeString(queryPlate, normQuery);
    Xe* results = (Xe*)malloc(10 * sizeof(Xe));
    int exactCount = 0;
    *resultCount = 0;

    // Phase 1: Uu tien TTIM CHINHX AC (Score = 0) theo ca Ma the va Bien so
    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT->buckets[i];
        while (curr != NULL) {
            char normCard[50], normPlate[50];
            normalizeString(curr->xe.maThe, normCard);
            normalizeString(curr->xe.bienSo, normPlate);

            if (strcmp(normQuery, normCard) == 0 || strcmp(normQuery, normPlate) == 0) {
                results[exactCount++] = curr->xe;
            }
            curr = curr->next;
        }
    }

    // Neu da tim thay ket qua chinh xac 100% -> Chi tra ve ket qua chinh xac!
    if (exactCount > 0) {
        *resultCount = exactCount;
        return results;
    }

    // Phase 2: Neu khong co ket qua chinh xac -> Tim mờ Levenshtein (Score <= 3)
    int topScores[3] = { INF, INF, INF };
    int fuzzyCount = 0;

    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT->buckets[i];
        while (curr != NULL) {
            char normCard[50], normPlate[50];
            normalizeString(curr->xe.maThe, normCard);
            normalizeString(curr->xe.bienSo, normPlate);

            int scoreCard = getLevenshteinDistance(normQuery, normCard);
            int scorePlate = getLevenshteinDistance(normQuery, normPlate);
            int score = (scoreCard < scorePlate) ? scoreCard : scorePlate;

            if (score <= 3 && score < topScores[2]) {
                topScores[2] = score;
                results[2] = curr->xe;

                for (int m = 0; m < 2; m++) {
                    for (int n = 2; n > m; n--) {
                        if (topScores[n] < topScores[n - 1]) {
                            int ts = topScores[n]; topScores[n] = topScores[n - 1]; topScores[n - 1] = ts;
                            Xe tx = results[n]; results[n] = results[n - 1]; results[n - 1] = tx;
                        }
                    }
                }
                if (fuzzyCount < 3) fuzzyCount++;
            }
            curr = curr->next;
        }
    }

    *resultCount = fuzzyCount;
    return results;
}