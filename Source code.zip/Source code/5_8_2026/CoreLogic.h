#pragma once
#ifndef CORE_LOGIC_H
#define CORE_LOGIC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "DataStructures.h" // Chuyen dung de nhung struct Xe, Graph, Queue, Stack, PriorityQueue, HashTable

#ifndef INF
#define INF 999999 // Gia tri vo cung dung cho Dijkstra
#endif

#ifndef MAX_NODES
#define MAX_NODES 305 // Toi da 300 o do + 1 cong vao
#endif

typedef struct {
    Xe xe;
    int score;
} FuzzyResult; // Cau truc tam luu ket qua so khop bien so

// MODULE 1: Quan ly Check-in, Suc chua & Doc Log
int getCurrentCarCount(HashTable* HT);
int processCheckIn(Xe newXe, HashTable* HT, Queue* Q, Graph* G, PriorityQueue* PQ, int maxAllowed);
void runSimulationFromLog(char* filename, HashTable* HT, Queue* Q, Graph* G, PriorityQueue* PQ, int maxAllowed);

// MODULE 2: Doc Ban do & Dan duong (Dijkstra)
void loadMapFromFile(char* filename, Graph* G);
int* findNearestSlot(Graph* G, int startNode, int isGiangVien, int* pathLength);
void printPath(int* path, int pathLength);

// MODULE 3: Quy hoach dong (Khung hoang khong gian)
Xe findAndEvictStudent(PriorityQueue* PQ, Stack* S, Graph* G, HashTable* HT);

// MODULE 4: Fuzzy Search (Tim xe nhieu bien so)
void normalizeString(char* src, char* dst);
int getLevenshteinDistance(char* s1, char* s2);
Xe* fuzzySearchLicensePlate(HashTable* HT, char* queryPlate, int* resultCount);

// MODULE 5: Check-out Tu dong hoa luong xe
float processCheckOut(char* maThe, int thoiGianRa, float donGia, HashTable* HT, Graph* G, Queue* Q, PriorityQueue* PQ, int maxAllowed);

#endif // CORE_LOGIC_H