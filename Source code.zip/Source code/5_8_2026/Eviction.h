#pragma once
#ifndef EVICTION_H
#define EVICTION_H

#include "DataStructures.h"

Xe findAndEvictStudent(PriorityQueue* PQ, Stack* S, Graph* G, HashTable* HT);

#endif // EVICTION_H