#define _CRT_SECURE_NO_WARNINGS
#include "CheckIn.h"
#include "Routing.h"
#include "CheckOut.h"
#include "FuzzySearch.h"
#include "Eviction.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Dem so xe hien dang do trong bai (duyet toan bo Hash Table)
int getCurrentCarCount(HashTable* HT) {
    int count = 0;
    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT->buckets[i];
        while (curr != NULL) { count++; curr = curr->next; }
    }
    return count;
}

// Kiem tra xe da ton tai trong bai chua (theo ma the hoac bien so)
int isCarAlreadyInParking(HashTable* HT, Xe newXe) {
    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT->buckets[i];
        while (curr != NULL) {
            if (strcmp(curr->xe.maThe, newXe.maThe) == 0) return 1; // Trung ma the
            if (strcmp(curr->xe.bienSo, newXe.bienSo) == 0) return 2; // Trung bien so
            curr = curr->next;
        }
    }
    return 0;
}

// Xu ly check-in: Kiem tra trung lap -> Suc chua -> Dijkstra -> Luu Hash Table
int processCheckIn(Xe newXe, HashTable* HT, Queue* Q, Graph* G, PriorityQueue* PQ, int maxAllowed) {
    // Kiem tra trung lap
    int dupe = isCarAlreadyInParking(HT, newXe);
    if (dupe == 1) {
        printf("[LOI CHECK-IN] KHONG THE QUET THE: Trung ma the '%s' (Ma the nay da co xe trong bai su dung)!\n", newXe.maThe);
        return -2;
    }
    if (dupe == 2) {
        printf("[LOI CHECK-IN] KHONG THE QUET THE: Trung bien so '%s' (Bien so nay da co xe do trong bai)!\n", newXe.bienSo);
        return -3;
    }

    int totalCars = getCurrentCarCount(HT);
    int physicalCapacity = G->n - 1; // 300

    // Kiem tra bai day vat ly 100% (300 xe)
    if (totalCars >= physicalCapacity) {
        printf("Bai day vat ly (%d/%d xe). Xe %s vao Hang doi Queue.\n", totalCars, physicalCapacity, newXe.bienSo);
        EnQueue(Q, newXe);
        return -1;
    }

    // Dem so xe Sinh vien hien co trong bai
    int totalStudentCars = 0;
    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT->buckets[i];
        while (curr) {
            if (curr->xe.isGiangVien == 0) totalStudentCars++;
            curr = curr->next;
        }
    }

    // Neu xe GV vao ma Khu GV (1-100) day -> Di doi xe SV do ke trong Min-Heap
    if (newXe.isGiangVien == 1) {
        int occupiedGV = 0;
        for (int i = 1; i <= 100; i++)
            if (G->zoneType[i] == 1 && G->isOccupied[i]) occupiedGV++;
        
        if (occupiedGV >= 100 && PQ->size > 0) {
            Stack tempStack; initStack(&tempStack);
            printf("[GIANG VIEN VAO] Khu GV day 100/100 o. Kich hoat di doi xe SV do ke...\n");
            findAndEvictStudent(PQ, &tempStack, G, HT);
        }
    }

    // Neu xe SV vao ma tong xe SV >= maxAllowed (vi du >= 10 xe)
    // Xe SV bat buoc phai chuyen sang tim o do ke trong KHU GIANG VIEN (zoneType == 1)!
    int forceFacultyZoneForSV = 0;
    if (newXe.isGiangVien == 0 && totalStudentCars >= maxAllowed) {
        forceFacultyZoneForSV = 1;
    }

    // Tim o do trong gan nhat bang Dijkstra
    int pathLength = 0;
    int* path = NULL;

    if (forceFacultyZoneForSV) {
        // Tim o do trong o Khu Giảng Viên cho SV do ke
        int dist[MAX_NODES], visited[MAX_NODES], trace[MAX_NODES];
        for (int i = 0; i < G->n; i++) { dist[i] = INF; visited[i] = 0; trace[i] = -1; }
        dist[0] = 0;

        for (int count = 0; count < G->n - 1; count++) {
            int u = -1, min_dist = INF;
            for (int i = 0; i < G->n; i++) {
                if (!visited[i] && dist[i] < min_dist) { min_dist = dist[i]; u = i; }
            }
            if (u == -1) break;
            visited[u] = 1;
            for (int v = 0; v < G->n; v++) {
                if (G->matrix[u][v] != 0 && !visited[v] && dist[u] + G->matrix[u][v] < dist[v]) {
                    dist[v] = dist[u] + G->matrix[u][v];
                    trace[v] = u;
                }
            }
        }

        // Tim o trong thuoc Khu GV (zoneType == 1)
        int target = -1, min_d = INF;
        for (int i = 1; i <= 100; i++) {
            if (G->zoneType[i] == 1 && G->isOccupied[i] == 0 && dist[i] < min_d) {
                target = i; min_d = dist[i];
            }
        }

        if (target != -1) {
            path = (int*)malloc(MAX_NODES * sizeof(int));
            int curr = target, len = 0;
            while (curr != -1) { path[len++] = curr; curr = trace[curr]; }
            pathLength = len;
            lastDijkstraPathLen = len;
            for (int i = 0; i < len; i++) lastDijkstraPath[i] = path[i];
        }
    } else {
        path = findNearestSlot(G, 0, newXe.isGiangVien, &pathLength);
    }

    if (path != NULL && pathLength > 0) {
        newXe.viTriDo = path[0];
        G->isOccupied[newXe.viTriDo] = 1;

        // Neu Xe Sinh Vien do ke vao Khu Giảng Viên (zoneType == 1) -> Luu vao Min-Heap PQ!
        if (newXe.isGiangVien == 0 && G->zoneType[newXe.viTriDo] == 1) {
            pushPQ(PQ, newXe);
            printf("[THONG BAO] SV da dat gioi han (%d/%d xe). Xe SV %s duoc DO KE vao Khu GV (O %d) -> Da luu vao Min-Heap!\nDan duong Dijkstra: ",
                   totalStudentCars + 1, maxAllowed, newXe.bienSo, newXe.viTriDo);
        } else {
            printf("Xe %s (%s) vao bai do THANH CONG -> Do tai O %d.\nDan duong Dijkstra: ",
                   newXe.bienSo, newXe.isGiangVien ? "Giang Vien" : "Sinh Vien", newXe.viTriDo);
        }

        insertHash(HT, newXe);
        printPath(path, pathLength);
        free(path);
        return newXe.viTriDo;
    } else {
        printf("Het o do hop le cho xe SV %s (Gioi han %d xe). Vao Hang doi Queue.\n", newXe.bienSo, maxAllowed);
        EnQueue(Q, newXe);
        if (path) free(path);
        return -1;
    }
}

// Nhap su kien thu cong tu ban phim (IN, OUT, FIND, EXIT)
void runSimulationFromConsole(HashTable* HT, Queue* Q, Graph* G, PriorityQueue* PQ, int maxAllowed) {
    char cmd[20];
    printf("\n=== CHE DO NHAP SK THU CONG ===\n");
    printf("IN <the> <bien_so> <0/1> <phut> | OUT <the_hoac_bien_so> <phut> | FIND <bien_so> | EXIT\n");

    while (1) {
        printf("\n> ");
        if (scanf("%s", cmd) == EOF) break;
        if (strcmp(cmd, "EXIT") == 0 || strcmp(cmd, "exit") == 0) break;

        if (strcmp(cmd, "IN") == 0) {
            Xe x; x.viTriDo = -1;
            if (scanf("%s %s %d %d", x.maThe, x.bienSo, &x.isGiangVien, &x.thoiGianVao) == 4)
                processCheckIn(x, HT, Q, G, PQ, maxAllowed);
            else { printf("Sai cu phap!\n"); int c; while((c=getchar())!='\n'&&c!=EOF); }
        }
        else if (strcmp(cmd, "OUT") == 0) {
            char query[50]; int t;
            if (scanf("%s %d", query, &t) == 2)
                processCheckOut(query, t, 2.0, HT, G, Q, PQ, maxAllowed);
            else { printf("Sai cu phap!\n"); int c; while((c=getchar())!='\n'&&c!=EOF); }
        }
        else if (strcmp(cmd, "FIND") == 0) {
            char q[50]; int cnt = 0;
            if (scanf("%s", q) == 1) {
                Xe* res = fuzzySearchLicensePlate(HT, q, &cnt);
                if (res && cnt > 0) {
                    for (int i = 0; i < cnt; i++)
                        printf(" - %d: %s (O %d)\n", i+1, res[i].bienSo, res[i].viTriDo);
                    free(res);
                } else printf(" Khong tim thay.\n");
            }
        }
        else { printf("Lenh sai! Dung: IN, OUT, FIND, EXIT\n"); int c; while((c=getchar())!='\n'&&c!=EOF); }
    }
}