#pragma once
#ifndef ROUTING_H
#define ROUTING_H

#include "DataStructures.h"

#ifndef INF
#define INF 999999
#endif

#ifndef MAX_NODES
#define MAX_NODES 305
#endif

extern int lastDijkstraPath[MAX_NODES];
extern int lastDijkstraPathLen;

void loadMapFromFile(char* filename, Graph* G);
int* findNearestSlot(Graph* G, int startNode, int isGiangVien, int* pathLength);
void printPath(int* path, int pathLength);

#endif // ROUTING_H