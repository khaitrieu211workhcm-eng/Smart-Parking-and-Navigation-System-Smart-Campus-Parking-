#define _CRT_SECURE_NO_WARNINGS
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <io.h>
#include <fcntl.h>

#include "DataStructures.h"
#include "CheckIn.h"
#include "CheckOut.h"
#include "Eviction.h"
#include "FuzzySearch.h"
#include "Routing.h"

// Control IDs
#define IDC_IN_CARD      101
#define IDC_IN_PLATE     102
#define IDC_IN_TYPE      103
#define IDC_IN_TIME      104
#define IDC_BTN_CHECKIN  105

#define IDC_OUT_QUERY    106
#define IDC_OUT_TIME     107
#define IDC_BTN_CHECKOUT 108

#define IDC_SEARCH_KEY   109
#define IDC_BTN_SEARCH   110
#define IDC_BTN_EVICT    111

#define IDC_NEW_LIMIT    112
#define IDC_BTN_LIMIT    113

#define IDC_LOG_BOX      114
#define IDC_MAP_CANVAS   115

#define IDC_LBL_COUNT    116
#define IDC_LBL_LIMIT    117
#define IDC_LBL_QUEUE    118
#define IDC_LBL_HEAP     119
#define IDC_HASH_BOX     120
#define IDC_QUEUE_BOX    121

// 10 Scenario Button IDs
#define IDC_SCENARIO_1   201
#define IDC_SCENARIO_2   202
#define IDC_SCENARIO_3   203
#define IDC_SCENARIO_4   204
#define IDC_SCENARIO_5   205
#define IDC_SCENARIO_6   206
#define IDC_SCENARIO_7   207
#define IDC_SCENARIO_8   208
#define IDC_SCENARIO_9   209
#define IDC_SCENARIO_10  210

// Global State
static Graph G;
static HashTable HT;
static Queue Q;
static PriorityQueue PQ;
static Stack S;
static int maxAllowed = 300;
static int physicalCapacity = 300;

// Active Dijkstra Route State for Map Canvas
static int activePath[MAX_NODES];
static int activePathLen = 0;
static int selectedSlot = -1;

// Handles for Responsive Layout Engine
static HWND hMainWnd = NULL;

static HWND hGroupStatus = NULL;
static HWND hLblCount = NULL;
static HWND hLblLimit = NULL;
static HWND hLblQueue = NULL;
static HWND hLblHeap = NULL;

static HWND hGroupMap = NULL;
static HWND hMapCanvas = NULL;

static HWND hGroupLog = NULL;
static HWND hLogBox = NULL;

static HWND hGroupHash = NULL;
static HWND hHashBox = NULL;

static HWND hGroupQueue = NULL;
static HWND hQueueBox = NULL;

static HWND hGroupIn = NULL;
static HWND hInCardLbl = NULL, hInCard = NULL;
static HWND hInPlateLbl = NULL, hInPlate = NULL;
static HWND hInTypeLbl = NULL, hInType = NULL;
static HWND hInTimeLbl = NULL, hInTime = NULL;
static HWND hBtnCheckIn = NULL;

static HWND hGroupOut = NULL;
static HWND hOutQueryLbl = NULL, hOutQuery = NULL;
static HWND hOutTimeLbl = NULL, hOutTime = NULL;
static HWND hBtnCheckOut = NULL;

static HWND hGroupSearch = NULL;
static HWND hSearchKeyLbl = NULL, hSearchKey = NULL, hBtnSearch = NULL;
static HWND hNewLimitLbl = NULL, hNewLimit = NULL, hBtnLimit = NULL, hBtnEvict = NULL;

static HWND hGroupScenarios = NULL;
static HWND hBtnScenario[10] = { NULL };

// Pipe for capturing stdout (printf)
static HANDLE hPipeRead = NULL;
static HANDLE hPipeWrite = NULL;

// UTF-8 to UTF-16 Unicode Helper
const wchar_t* U(const char* utf8Str) {
    static wchar_t wbuf[16][2048];
    static int idx = 0;
    if (!utf8Str) return L"";
    idx = (idx + 1) % 16;
    MultiByteToWideChar(CP_UTF8, 0, utf8Str, -1, wbuf[idx], 2048);
    return wbuf[idx];
}

HWND CreateControlU(const char* className, const char* text, DWORD style, int x, int y, int w, int h, HWND hParent, HMENU hMenu) {
    return CreateWindowW(U(className), U(text), style, x, y, w, h, hParent, hMenu, NULL, NULL);
}

void SetTextU(HWND hwnd, const char* text) {
    SetWindowTextW(hwnd, U(text));
}

void GetTextU(HWND hwnd, char* dst, int maxLen) {
    wchar_t wbuf[1024];
    GetWindowTextW(hwnd, wbuf, 1024);
    WideCharToMultiByte(CP_UTF8, 0, wbuf, -1, dst, maxLen, NULL, NULL);
}

void appendLogU(const char* utf8Text) {
    if (!hLogBox) return;
    int len = GetWindowTextLengthW(hLogBox);
    SendMessageW(hLogBox, EM_SETSEL, (WPARAM)len, (LPARAM)len);
    SendMessageW(hLogBox, EM_REPLACESEL, FALSE, (LPARAM)U(utf8Text));
    SendMessageW(hLogBox, EM_SCROLLCARET, 0, 0);
}

void setupStdoutPipe() {
    SECURITY_ATTRIBUTES sa = { sizeof(SECURITY_ATTRIBUTES), NULL, TRUE };
    if (CreatePipe(&hPipeRead, &hPipeWrite, &sa, 0)) {
        SetStdHandle(STD_OUTPUT_HANDLE, hPipeWrite);
        int fd = _open_osfhandle((intptr_t)hPipeWrite, _O_TEXT);
        if (fd >= 0) {
            _dup2(fd, _fileno(stdout));
            setvbuf(stdout, NULL, _IONBF, 0);
        }
    }
}

void flushPrintfToLog() {
    fflush(stdout);
    DWORD avail = 0;
    if (PeekNamedPipe(hPipeRead, NULL, 0, NULL, &avail, NULL) && avail > 0) {
        char* buf = (char*)malloc(avail + 1);
        if (buf) {
            DWORD readBytes = 0;
            if (ReadFile(hPipeRead, buf, avail, &readBytes, NULL)) {
                buf[readBytes] = '\0';
                appendLogU(buf);
            }
            free(buf);
        }
    }
}

int getKeCount() {
    int keCount = 0;
    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT.buckets[i];
        while (curr) {
            if (curr->xe.isGiangVien == 0 && G.zoneType[curr->xe.viTriDo] == 1) {
                keCount++;
            }
            curr = curr->next;
        }
    }
    return keCount;
}

void renderHashTableToGUI() {
    if (!hHashBox) return;
    char* bigBuf = (char*)malloc(65536);
    if (!bigBuf) return;

    bigBuf[0] = '\0';
    int totalElements = 0;
    int activeBuckets = 0;

    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT.buckets[i];
        if (curr != NULL) {
            activeBuckets++;
            char line[512];
            sprintf(line, "Bucket [%03d]: ", i);
            strcat(bigBuf, line);

            while (curr != NULL) {
                totalElements++;
                sprintf(line, "[Thẻ: %s | Biển: %s | Ô: %d]",
                        curr->xe.maThe, curr->xe.bienSo, curr->xe.viTriDo);
                strcat(bigBuf, line);

                if (curr->next != NULL) {
                    strcat(bigBuf, " -> ");
                }
                curr = curr->next;
            }
            strcat(bigBuf, "\r\n");
        }
    }

    if (totalElements == 0) {
        SetTextU(hHashBox, "=== BẢNG BĂM (HASH TABLE) TRỐNG ===\r\nHiện chưa có xe nào đỗ trong Bảng Băm.\r\nKích thước Bảng băm: 101 Buckets (Separate Chaining).\r\nQuẹt thẻ xe vào hoặc bấm các Nút Kịch Bản để xem liên kết các Buckets!");
    } else {
        char header[256];
        sprintf(header, "=== TÌNH TRẠNG BẢNG BĂM (HASH TABLE - 101 BUCKETS) ===\r\nTổng xe đỗ: %d xe | Buckets đang dùng: %d / 101\r\n---------------------------------------------------------\r\n",
                totalElements, activeBuckets);
        char* finalBuf = (char*)malloc(70000);
        if (finalBuf) {
            strcpy(finalBuf, header);
            strcat(finalBuf, bigBuf);
            SetTextU(hHashBox, finalBuf);
            free(finalBuf);
        }
    }

    free(bigBuf);
}

void renderQueueToGUI() {
    if (!hQueueBox) return;
    char* bigBuf = (char*)malloc(16384);
    if (!bigBuf) return;

    bigBuf[0] = '\0';
    int count = 0;
    QueueNode* curr = Q.front;

    while (curr != NULL) {
        count++;
        char line[256];
        sprintf(line, " [%d] Thẻ: %s | Biển: %s | %s | VÀO: %02dh%02d\r\n",
                count, curr->xe.maThe, curr->xe.bienSo,
                curr->xe.isGiangVien ? "Giảng Viên" : "Sinh Viên",
                curr->xe.thoiGianVao / 60, curr->xe.thoiGianVao % 60);
        strcat(bigBuf, line);
        curr = curr->next;
    }

    if (count == 0) {
        SetTextU(hQueueBox, "=== HÀNG ĐỜI QUEUE TRỐNG ===\r\n(Không có xe nào đang chờ ở cổng)\r\nKhi bãi đầy/vượt giới hạn, xe sẽ xếp hàng tại đây theo FIFO.");
    } else {
        char header[256];
        sprintf(header, "=== HÀNG ĐỜI CỔNG (QUEUE FIFO) ===\r\nSố xe đang chờ: %d xe\r\n-----------------------------------\r\n", count);
        char* finalBuf = (char*)malloc(20000);
        if (finalBuf) {
            strcpy(finalBuf, header);
            strcat(finalBuf, bigBuf);
            SetTextU(hQueueBox, finalBuf);
            free(finalBuf);
        }
    }

    free(bigBuf);
}

void updateStatusLabels() {
    char buf[128];
    int currentCars = getCurrentCarCount(&HT);
    
    sprintf(buf, "Đang đỗ: %d / %d xe", currentCars, physicalCapacity);
    SetTextU(hLblCount, buf);

    sprintf(buf, "Giới hạn SV: %d xe", maxAllowed);
    SetTextU(hLblLimit, buf);

    int qCount = 0;
    QueueNode* qCurr = Q.front;
    while (qCurr) { qCount++; qCurr = qCurr->next; }
    sprintf(buf, "Hàng chờ ở cổng: %d xe", qCount);
    SetTextU(hLblQueue, buf);

    sprintf(buf, "Xe SV đỗ ké (Heap): %d xe", getKeCount());
    SetTextU(hLblHeap, buf);

    renderHashTableToGUI();
    renderQueueToGUI();

    if (hMapCanvas) {
        InvalidateRect(hMapCanvas, NULL, TRUE);
    }
}

// ---------------------------------------------------------------------------
// DYNAMIC RESPONSIVE LAYOUT ENGINE (WM_SIZE)
// ---------------------------------------------------------------------------
void layoutControls(int W, int H) {
    if (W <= 0 || H <= 0 || !hMainWnd) return;

    // 1. Top Header Status Panel
    MoveWindow(hGroupStatus, 10, 8, W - 20, 56, TRUE);
    int statusW = (W - 40) / 4;
    MoveWindow(hLblCount, 20 + 0 * statusW, 30, statusW - 10, 20, TRUE);
    MoveWindow(hLblLimit, 20 + 1 * statusW, 30, statusW - 10, 20, TRUE);
    MoveWindow(hLblQueue, 20 + 2 * statusW, 30, statusW - 10, 20, TRUE);
    MoveWindow(hLblHeap,  20 + 3 * statusW, 30, statusW - 10, 20, TRUE);

    // 2. Left Column Width (60%), Right Column Width (40%)
    int leftW = (W - 35) * 60 / 100;
    int rightX = 10 + leftW + 15;
    int rightW = W - rightX - 10;

    int mapH = (H - 80) * 62 / 100;
    if (mapH < 430) mapH = 430;

    // Left Top: 2D Map Canvas
    MoveWindow(hGroupMap, 10, 70, leftW, mapH, TRUE);
    MoveWindow(hMapCanvas, 20, 92, leftW - 20, mapH - 28, TRUE);

    // Left Bottom: Operational Log, Hash Table & Queue Box (Split 33:33:33)
    int botY = 70 + mapH + 10;
    int botH = H - botY - 10;
    if (botH < 180) botH = 180;

    int boxW = (leftW - 20) / 3;
    MoveWindow(hGroupLog, 10, botY, boxW, botH, TRUE);
    MoveWindow(hLogBox, 18, botY + 22, boxW - 16, botH - 30, TRUE);

    MoveWindow(hGroupHash, 10 + boxW + 10, botY, boxW, botH, TRUE);
    MoveWindow(hHashBox, 10 + boxW + 18, botY + 22, boxW - 16, botH - 30, TRUE);

    MoveWindow(hGroupQueue, 10 + 2 * (boxW + 10), botY, boxW, botH, TRUE);
    MoveWindow(hQueueBox, 10 + 2 * (boxW + 10) + 8, botY + 22, boxW - 16, botH - 30, TRUE);

    // Right Column Panels
    // Panel 1: Check-In
    MoveWindow(hGroupIn, rightX, 70, rightW, 145, TRUE);
    int inW = (rightW - 150) / 2;
    if (inW < 70) inW = 70;

    MoveWindow(hInCardLbl, rightX + 15, 93, 60, 20, TRUE);
    MoveWindow(hInCard, rightX + 80, 91, inW, 22, TRUE);

    MoveWindow(hInPlateLbl, rightX + 90 + inW, 93, 55, 20, TRUE);
    MoveWindow(hInPlate, rightX + 150 + inW, 91, inW, 22, TRUE);

    MoveWindow(hInTypeLbl, rightX + 15, 122, 65, 20, TRUE);
    MoveWindow(hInType, rightX + 80, 120, inW, 120, TRUE);

    MoveWindow(hInTimeLbl, rightX + 90 + inW, 122, 55, 20, TRUE);
    MoveWindow(hInTime, rightX + 150 + inW, 120, 60, 22, TRUE);

    MoveWindow(hBtnCheckIn, rightX + 15, 172, rightW - 30, 30, TRUE);

    // Panel 2: Check-Out
    MoveWindow(hGroupOut, rightX, 222, rightW, 128, TRUE);
    MoveWindow(hOutQueryLbl, rightX + 15, 245, 110, 20, TRUE);
    MoveWindow(hOutQuery, rightX + 130, 243, rightW - 145, 22, TRUE);

    MoveWindow(hOutTimeLbl, rightX + 15, 275, 110, 20, TRUE);
    MoveWindow(hOutTime, rightX + 130, 273, 80, 22, TRUE);

    MoveWindow(hBtnCheckOut, rightX + 15, 305, rightW - 30, 32, TRUE);

    // Panel 3: Search & Limit
    MoveWindow(hGroupSearch, rightX, 357, rightW, 125, TRUE);
    MoveWindow(hSearchKeyLbl, rightX + 15, 380, 85, 20, TRUE);
    MoveWindow(hSearchKey, rightX + 105, 378, rightW - 215, 22, TRUE);
    MoveWindow(hBtnSearch, rightX + rightW - 100, 377, 85, 24, TRUE);

    MoveWindow(hNewLimitLbl, rightX + 15, 414, 95, 20, TRUE);
    MoveWindow(hNewLimit, rightX + 115, 412, 60, 22, TRUE);
    
    int subBtnW = (rightW - 195) / 2;
    if (subBtnW < 80) subBtnW = 80;
    MoveWindow(hBtnLimit, rightX + 182, 411, subBtnW, 24, TRUE);
    MoveWindow(hBtnEvict, rightX + 188 + subBtnW, 411, subBtnW, 24, TRUE);

    // Panel 4: 10 Quick Scenarios
    int scY = 489;
    int scH = H - scY - 10;
    if (scH < 220) scH = 220;
    MoveWindow(hGroupScenarios, rightX, scY, rightW, scH, TRUE);

    int btnW = (rightW - 35) / 2;
    int rowH = (scH - 32) / 5;
    if (rowH < 32) rowH = 32;

    for (int i = 0; i < 10; i++) {
        int r = i / 2;
        int c = i % 2;
        int bx = rightX + 15 + c * (btnW + 10);
        int by = scY + 24 + r * rowH;
        MoveWindow(hBtnScenario[i], bx, by, btnW, rowH - 4, TRUE);
    }
}

// ---------------------------------------------------------------------------
// INTERACTIVE 2D PARKING LOT MAP CANVAS (GDI Double Buffer + Dynamic Scaling)
// ---------------------------------------------------------------------------
int isNodeInPath(int nodeID) {
    for (int i = 0; i < activePathLen; i++) {
        if (activePath[i] == nodeID) return 1;
    }
    return 0;
}

Xe* findCarInSlot(int slotID) {
    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT.buckets[i];
        while (curr) {
            if (curr->xe.viTriDo == slotID) return &(curr->xe);
            curr = curr->next;
        }
    }
    return NULL;
}

LRESULT CALLBACK MapCanvasWndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    const int cols = 20;

    switch (msg) {
    case WM_LBUTTONDOWN: {
        int mx = LOWORD(lParam);
        int my = HIWORD(lParam);
        RECT rcCanvas;
        GetClientRect(hwnd, &rcCanvas);
        int width = rcCanvas.right - rcCanvas.left;
        int height = rcCanvas.bottom - rcCanvas.top;

        int slotW = (width - 40) / cols - 2;
        if (slotW < 22) slotW = 22;
        if (slotW > 50) slotW = 50;

        int rows = 16;
        int gapX = 2, gapY = 2;
        int aisleH = 10;

        int totalAisleOffset = 7 * aisleH;
        int availableH = height - 32 - totalAisleOffset;
        int slotH = (availableH / rows) - gapY;
        if (slotH < 12) slotH = 12;
        if (slotH > 22) slotH = 22;

        int totalWidthNeeded = cols * (slotW + gapX);
        int startX = (width - totalWidthNeeded) / 2;
        if (startX < 10) startX = 10;
        int startY = 30;

        int clicked = -1;
        for (int i = 0; i <= 300; i++) {
            int row = i / cols;
            int col = i % cols;
            int aisleIndex = row / 2;
            int aisleOffset = aisleIndex * aisleH;
            int x = startX + col * (slotW + gapX);
            int y = startY + row * (slotH + gapY) + aisleOffset;

            if (mx >= x && mx <= x + slotW && my >= y && my <= y + slotH) {
                clicked = i;
                break;
            }
        }

        if (clicked >= 0) {
            selectedSlot = clicked;
            InvalidateRect(hwnd, NULL, FALSE);

            char buf[512];
            if (clicked == 0) {
                sprintf(buf, "\r\n[TƯƠNG TÁC Ô ĐỖ] Click Ô 0: CỔNG CHÍNH ĐỒ THỊ (Điểm xuất phát dẫn đường Dijkstra)\r\n");
                appendLogU(buf);
            } else {
                Xe* pXe = findCarInSlot(clicked);
                if (pXe) {
                    char typeStr[64];
                    if (pXe->isGiangVien == 1) {
                        strcpy(typeStr, "Giảng Viên (Khu GV)");
                    } else {
                        if (G.zoneType[clicked] == 1) {
                            strcpy(typeStr, "Sinh Viên (Khu GV)");
                        } else {
                            strcpy(typeStr, "Sinh Viên (Khu SV)");
                        }
                    }

                    sprintf(buf, "\r\n[TƯƠNG TÁC Ô ĐỖ %d] TRẠNG THÁI: ĐÃ ĐỖ XE\r\n  - Mã thẻ: %s\r\n  - Biển số: %s\r\n  - Loại xe: %s\r\n  - Giờ vào: %02dh%02d\r\n",
                        clicked, pXe->maThe, pXe->bienSo, typeStr,
                        pXe->thoiGianVao / 60, pXe->thoiGianVao % 60);
                    appendLogU(buf);
                    MessageBoxW(hwnd, U(buf), L"Thông Tin Chi Tiết Phương Tiện Đỗ", MB_OK | MB_ICONINFORMATION);
                } else {
                    int isGVZone = (G.zoneType[clicked] == 1);
                    sprintf(buf, "\r\n[TƯƠNG TÁC Ô ĐỖ %d] TRẠNG THÁI: Ô ĐỖ TRỐNG\r\n  - Phân khu: %s\r\n  - Sẵn sàng tiếp nhận xe vào đỗ.\r\n",
                        clicked, isGVZone ? "Khu vực Giảng Viên (Ô 1-100)" : "Khu vực Sinh Viên (Ô 101-300)");
                    appendLogU(buf);
                }
            }
        }
        return 0;
    }
    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdcScreen = BeginPaint(hwnd, &ps);
        RECT rc;
        GetClientRect(hwnd, &rc);
        int width = rc.right - rc.left;
        int height = rc.bottom - rc.top;

        HDC hdc = CreateCompatibleDC(hdcScreen);
        HBITMAP hbm = CreateCompatibleBitmap(hdcScreen, width, height);
        HBITMAP hbmOld = (HBITMAP)SelectObject(hdc, hbm);

        HBRUSH hbrBg = GetSysColorBrush(COLOR_BTNFACE);
        FillRect(hdc, &rc, hbrBg);

        SetBkMode(hdc, TRANSPARENT);

        HFONT hFontLegend = CreateFontW(12, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
        HFONT hOldFont = (HFONT)SelectObject(hdc, hFontLegend);

        SetTextColor(hdc, RGB(30, 41, 59));
        TextOutW(hdc, 12, 6, L"SƠ ĐỒ BÃI XE & DẪN ĐƯỜNG 2D", 27);

        int slotW = (width - 40) / cols - 2;
        if (slotW < 22) slotW = 22;
        if (slotW > 50) slotW = 50;

        int rows = 16;
        int gapX = 2, gapY = 2;
        int aisleH = 10;

        int totalAisleOffset = 7 * aisleH;
        int availableH = height - 32 - totalAisleOffset;
        int slotH = (availableH / rows) - gapY;
        if (slotH < 12) slotH = 12;
        if (slotH > 22) slotH = 22;

        int totalWidthNeeded = cols * (slotW + gapX);
        int startX = (width - totalWidthNeeded) / 2;
        if (startX < 10) startX = 10;
        int startY = 30;

        int lx = width - 480;
        if (lx < 280) lx = 280;
        
        HBRUSH hLeg0 = CreateSolidBrush(RGB(168, 85, 247));
        RECT rLeg0 = { lx, 8, lx + 12, 18 }; FillRect(hdc, &rLeg0, hLeg0); DeleteObject(hLeg0);
        TextOutW(hdc, lx + 15, 6, L"Cổng", 4); lx += 50;

        HBRUSH hLeg1 = CreateSolidBrush(RGB(6, 182, 212));
        RECT rLeg1 = { lx, 8, lx + 12, 18 }; FillRect(hdc, &rLeg1, hLeg1); DeleteObject(hLeg1);
        TextOutW(hdc, lx + 15, 6, L"Khu GV", 6); lx += 65;

        HBRUSH hLeg2 = CreateSolidBrush(RGB(236, 72, 153));
        RECT rLeg2 = { lx, 8, lx + 12, 18 }; FillRect(hdc, &rLeg2, hLeg2); DeleteObject(hLeg2);
        TextOutW(hdc, lx + 15, 6, L"Khu SV", 6); lx += 65;

        HBRUSH hLeg3 = CreateSolidBrush(RGB(239, 68, 68));
        RECT rLeg3 = { lx, 8, lx + 12, 18 }; FillRect(hdc, &rLeg3, hLeg3); DeleteObject(hLeg3);
        TextOutW(hdc, lx + 15, 6, L"Đã đỗ", 5); lx += 60;

        HBRUSH hLeg4 = CreateSolidBrush(RGB(34, 197, 94));
        RECT rLeg4 = { lx, 8, lx + 12, 18 }; FillRect(hdc, &rLeg4, hLeg4); DeleteObject(hLeg4);
        TextOutW(hdc, lx + 15, 6, L"Lộ trình Dijkstra", 17);

        HFONT hFontSlot = CreateFontW(slotH - 5 > 8 ? slotH - 5 : 9, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");
        SelectObject(hdc, hFontSlot);

        HFONT hFontAisle = CreateFontW(8, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS, DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

        for (int i = 0; i <= 300; i++) {
            int row = i / cols;
            int col = i % cols;
            int aisleIndex = row / 2;
            int aisleOffset = aisleIndex * aisleH;

            int x = startX + col * (slotW + gapX);
            int y = startY + row * (slotH + gapY) + aisleOffset;

            if (col == 0 && row > 0 && row % 2 == 0) {
                int aisleY = y - 9;
                SelectObject(hdc, hFontAisle);
                SetTextColor(hdc, RGB(180, 83, 9));
                wchar_t aisleText[128];
                swprintf(aisleText, 128, L"---> LỐI ĐI CHUYỂN / DRIVING AISLE --->");
                RECT rAisle = { startX, aisleY, startX + cols * (slotW + gapX), aisleY + 9 };
                DrawTextW(hdc, aisleText, -1, &rAisle, DT_CENTER | DT_SINGLELINE);
                SelectObject(hdc, hFontSlot);
            }

            COLORREF fillColor;
            COLORREF textColor = RGB(255, 255, 255);

            if (i == 0) {
                fillColor = RGB(168, 85, 247);
            } else if (i == selectedSlot) {
                fillColor = RGB(245, 158, 11);
            } else if (isNodeInPath(i)) {
                fillColor = RGB(34, 197, 94);
                textColor = RGB(0, 0, 0);
            } else if (G.isOccupied[i]) {
                fillColor = RGB(239, 68, 68);
            } else if (G.zoneType[i] == 1) {
                fillColor = RGB(6, 182, 212);
            } else {
                fillColor = RGB(236, 72, 153);
            }

            HBRUSH hbrSlot = CreateSolidBrush(fillColor);
            HPEN hpenBorder = CreatePen(PS_SOLID, 1, (i == selectedSlot) ? RGB(255, 255, 255) : RGB(30, 41, 59));
            HBRUSH hOldBr = (HBRUSH)SelectObject(hdc, hbrSlot);
            HPEN hOldPen = (HPEN)SelectObject(hdc, hpenBorder);

            RoundRect(hdc, x, y, x + slotW, y + slotH, 3, 3);

            SelectObject(hdc, hOldBr);
            SelectObject(hdc, hOldPen);
            DeleteObject(hbrSlot);
            DeleteObject(hpenBorder);

            SetTextColor(hdc, textColor);
            wchar_t label[16];
            if (i == 0) swprintf(label, 16, L"CỔNG");
            else swprintf(label, 16, L"%d", i);

            RECT rText = { x, y, x + slotW, y + slotH };
            DrawTextW(hdc, label, -1, &rText, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
        }

        SelectObject(hdc, hOldFont);
        DeleteObject(hFontLegend);
        DeleteObject(hFontSlot);
        DeleteObject(hFontAisle);

        BitBlt(hdcScreen, 0, 0, width, height, hdc, 0, 0, SRCCOPY);
        SelectObject(hdc, hbmOld);
        DeleteObject(hbm);
        DeleteDC(hdc);

        EndPaint(hwnd, &ps);
        return 0;
    }
    case WM_ERASEBKGND:
        return 1;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// ---------------------------------------------------------------------------
// EVENT HANDLERS & 10 QUICK-TEST SCENARIOS
// ---------------------------------------------------------------------------
void onCheckIn() {
    char maThe[32], bienSo[32], strTime[32];
    GetTextU(hInCard, maThe, sizeof(maThe));
    GetTextU(hInPlate, bienSo, sizeof(bienSo));
    GetTextU(hInTime, strTime, sizeof(strTime));
    int isGiangVien = (int)SendMessageW(hInType, CB_GETCURSEL, 0, 0);

    if (strlen(maThe) == 0 || strlen(bienSo) == 0) {
        appendLogU("[LỖI] Vui lòng nhập đầy đủ Mã Thẻ và Biển Số!\r\n");
        return;
    }

    int inTime = 480;
    if (strlen(strTime) > 0) {
        int h = 0, m = 0;
        if (sscanf(strTime, "%d:%d", &h, &m) == 2) inTime = h * 60 + m;
        else inTime = atoi(strTime);
    }

    Xe x;
    strcpy(x.maThe, maThe);
    strcpy(x.bienSo, bienSo);
    x.isGiangVien = isGiangVien;
    x.thoiGianVao = inTime;
    x.viTriDo = -1;

    char logHeader[256];
    sprintf(logHeader, "\r\n--- SỰ KIỆN CHECK-IN: Thẻ [%s] | Biển số [%s] | Đối tượng [%s] | Giờ vào %02dh%02d ---\r\n",
        maThe, bienSo, isGiangVien ? "Giảng Viên" : "Sinh Viên", inTime / 60, inTime % 60);
    appendLogU(logHeader);
    activePathLen = 0;
    selectedSlot = -1;

    int resSlot = processCheckIn(x, &HT, &Q, &G, &PQ, maxAllowed);
    
    if (resSlot == -2) {
        char errMsg[256];
        sprintf(errMsg, "[LỖI TỒN TẠI] Trùng Mã Thẻ: Mã thẻ [%s] đã có xe đỗ trong bãi!", x.maThe);
        MessageBoxW(hMainWnd, U(errMsg), L"Lỗi Trùng Mã Thẻ", MB_OK | MB_ICONERROR);
    } else if (resSlot == -3) {
        char errMsg[256];
        sprintf(errMsg, "[LỖI TỒN TẠI] Trùng Biển Số: Biển số [%s] đã có xe đỗ trong bãi!", x.bienSo);
        MessageBoxW(hMainWnd, U(errMsg), L"Lỗi Trùng Biển Số", MB_OK | MB_ICONERROR);
    }

    if (resSlot > 0 && lastDijkstraPathLen > 0) {
        activePathLen = lastDijkstraPathLen;
        for (int i = 0; i < lastDijkstraPathLen; i++) {
            activePath[i] = lastDijkstraPath[i];
        }
    }

    flushPrintfToLog();
    updateStatusLabels();

    SetTextU(hInCard, "");
    SetTextU(hInPlate, "");
}

void onCheckOut() {
    char query[64], strTime[32];
    GetTextU(hOutQuery, query, sizeof(query));
    GetTextU(hOutTime, strTime, sizeof(strTime));

    if (strlen(query) == 0) {
        appendLogU("[LỖI] Vui lòng nhập Mã Thẻ hoặc Biển Số để Check-Out!\r\n");
        return;
    }

    int outTime = 630;
    if (strlen(strTime) > 0) {
        int h = 0, m = 0;
        if (sscanf(strTime, "%d:%d", &h, &m) == 2) outTime = h * 60 + m;
        else outTime = atoi(strTime);
    }

    char logHeader[256];
    sprintf(logHeader, "\r\n--- SỰ KIỆN CHECK-OUT: Tìm thẻ/biển [%s] | Giờ ra %02dh%02d ---\r\n",
        query, outTime / 60, outTime % 60);
    appendLogU(logHeader);
    activePathLen = 0;
    selectedSlot = -1;

    processCheckOut(query, outTime, 2.0f, &HT, &G, &Q, &PQ, maxAllowed);
    flushPrintfToLog();
    updateStatusLabels();

    SetTextU(hOutQuery, "");
}

void onSearch() {
    char qPlate[64];
    GetTextU(hSearchKey, qPlate, sizeof(qPlate));

    if (strlen(qPlate) == 0) {
        appendLogU("[LỖI] Vui lòng nhập biển số xe để tìm kiếm!\r\n");
        return;
    }

    appendLogU("\r\n--- TÌM KIẾM THÔNG TIN BIỂN SỐ XE ---\r\n");
    activePathLen = 0;
    selectedSlot = -1;

    int count = 0;
    Xe* res = fuzzySearchLicensePlate(&HT, qPlate, &count);
    if (res && count > 0) {
        char buf[256];
        sprintf(buf, "Tìm thấy %d kết quả phù hợp cho từ khóa '%s':\r\n", count, qPlate);
        appendLogU(buf);
        for (int i = 0; i < count; i++) {
            char typeStr[64];
            if (res[i].isGiangVien == 1) {
                strcpy(typeStr, "Giảng Viên (Khu GV)");
            } else {
                if (G.zoneType[res[i].viTriDo] == 1) {
                    strcpy(typeStr, "Sinh Viên (Khu GV)");
                } else {
                    strcpy(typeStr, "Sinh Viên (Khu SV)");
                }
            }

            sprintf(buf, "  [%d] Thẻ: %s | Biển số: %s | Loại xe: %s | Ô đỗ: %d | Giờ vào: %02dh%02d\r\n",
                i + 1, res[i].maThe, res[i].bienSo, typeStr,
                res[i].viTriDo, res[i].thoiGianVao / 60, res[i].thoiGianVao % 60);
            appendLogU(buf);
            
            if (i == 0) {
                selectedSlot = res[i].viTriDo;
            }
        }
        free(res);
    } else {
        appendLogU("Không tìm thấy phương tiện phù hợp trong hệ thống.\r\n");
    }
    updateStatusLabels();
}

void onEvict() {
    appendLogU("\r\n--- THAO TÁC DI DỜI XE SV ĐỖ KÉ (MIN-HEAP & STACK) ---\r\n");
    activePathLen = 0;
    selectedSlot = -1;

    if (PQ.size > 0) {
        findAndEvictStudent(&PQ, &S, &G, &HT);
        flushPrintfToLog();
    } else {
        appendLogU("Hiện không có xe Sinh Viên nào đỗ ké khu Giảng Viên.\r\n");
    }
    updateStatusLabels();
}

void onSetLimit() {
    char strLimit[32];
    GetTextU(hNewLimit, strLimit, sizeof(strLimit));
    int val = atoi(strLimit);
    if (val > 0) {
        maxAllowed = val;
        char buf[128];
        sprintf(buf, "\r\n[HỆ THỐNG] Đã cập nhật giới hạn đỗ xe SV = %d\r\n", maxAllowed);
        appendLogU(buf);

        while (!isEmptyQueue(&Q) && getCurrentCarCount(&HT) < maxAllowed) {
            Xe x;
            DeQueue(&Q, &x);
            sprintf(buf, ">> Gọi xe %s từ Hàng đợi vào đỗ:\r\n", x.bienSo);
            appendLogU(buf);
            processCheckIn(x, &HT, &Q, &G, &PQ, maxAllowed);
            flushPrintfToLog();
        }
        updateStatusLabels();
    } else {
        appendLogU("[LỖI] Giới hạn mới phải là số nguyên dương!\r\n");
    }
}

// ---------------------------------------------------------------------------
// IMPLEMENTATION OF 10 QUICK-TEST SCENARIOS
// ---------------------------------------------------------------------------
void runScenario1() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 1] MÔ PHỎNG LẤP ĐẦY KHU SINH VIÊN (200 Ô ĐỖ)\r\n");
    appendLogU("=========================================================\r\n");
    int added = 0;
    for (int i = 101; i <= 300; i++) {
        if (!G.isOccupied[i]) {
            Xe x;
            sprintf(x.maThe, "SV_SIM_%d", i);
            sprintf(x.bienSo, "59F1-%05d", i);
            x.isGiangVien = 0;
            x.thoiGianVao = 480 + (i % 60);
            x.viTriDo = i;
            G.isOccupied[i] = 1;
            insertHash(&HT, x);
            added++;
        }
    }
    char buf[128];
    sprintf(buf, "[KẾT QUẢ KB 1] Đã nạp thành công %d xe Sinh viên vào Khu SV (Ô 101-300).\r\n", added);
    appendLogU(buf);
    updateStatusLabels();
}

void runScenario2() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 2] MÔ PHỎNG LẤP ĐẦY KHU GIẢNG VIÊN (100 Ô ĐỖ)\r\n");
    appendLogU("=========================================================\r\n");
    int added = 0;
    for (int i = 1; i <= 100; i++) {
        if (!G.isOccupied[i]) {
            Xe x;
            sprintf(x.maThe, "GV_SIM_%d", i);
            sprintf(x.bienSo, "59A-%05d", i);
            x.isGiangVien = 1;
            x.thoiGianVao = 450 + (i % 30);
            x.viTriDo = i;
            G.isOccupied[i] = 1;
            insertHash(&HT, x);
            added++;
        }
    }
    char buf[128];
    sprintf(buf, "[KẾT QUẢ KB 2] Đã nạp thành công %d xe Giảng viên vào Khu GV (Ô 1-100).\r\n", added);
    appendLogU(buf);
    updateStatusLabels();
}

void runScenario3() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 3] MÔ PHỎNG BÃI ĐỖ XE ĐẦY 100% VẬT LÝ (300/300 Ô)\r\n");
    appendLogU("=========================================================\r\n");
    runScenario2();
    runScenario1();
    appendLogU("[KẾT QUẢ KB 3] Toàn bộ bãi xe đã kín 300/300 ô đỗ.\r\n");
    updateStatusLabels();
}

void runScenario4() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 4] ĐẶT GIỚI HẠN SV = 10 -> XE SV THỨ 11 ĐỖ KÉ KHU GV\r\n");
    appendLogU("=========================================================\r\n");
    maxAllowed = 10;
    SetTextU(hNewLimit, "10");
    char buf[128];
    sprintf(buf, "[HỆ THỐNG] Đã đặt Giới hạn đỗ SV = %d xe.\r\n", maxAllowed);
    appendLogU(buf);

    for (int i = 1; i <= 10; i++) {
        char card[20], plate[20];
        sprintf(card, "SV_CARD_%02d", i);
        sprintf(plate, "59F1-100%02d", i);
        Xe x = {0};
        strcpy(x.maThe, card);
        strcpy(x.bienSo, plate);
        x.isGiangVien = 0;
        x.thoiGianVao = 480 + i * 2;
        x.viTriDo = -1;
        processCheckIn(x, &HT, &Q, &G, &PQ, maxAllowed);
        flushPrintfToLog();
    }

    appendLogU("\r\n>>> CHO XE SV THỨ 11 VÀO (VƯỢT GIỚI HẠN 10 XE) <<<\r\n");
    Xe x11 = {"SV_CARD_11", "59F1-10011", 0, 510, -1};
    processCheckIn(x11, &HT, &Q, &G, &PQ, maxAllowed);
    flushPrintfToLog();
    updateStatusLabels();
}

void runScenario5() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 5] DI DỜI XE SV ĐỖ KÉ KHU GV (MIN-HEAP & STACK)\r\n");
    appendLogU("=========================================================\r\n");
    onEvict();
}

void runScenario6() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 6] KIỂM THỬ HÀNG ĐỜI VƯỢT GIỚI HẠN (QUEUE FIFO)\r\n");
    appendLogU("=========================================================\r\n");
    int currentCars = getCurrentCarCount(&HT);
    maxAllowed = currentCars;
    char buf[128];
    sprintf(buf, "10");
    SetTextU(hNewLimit, buf);

    for (int i = 1; i <= 3; i++) {
        Xe x;
        sprintf(x.maThe, "CARD_Q00%d", i);
        sprintf(x.bienSo, "59F1-Q00%d", i);
        x.isGiangVien = 0;
        x.thoiGianVao = 520 + i * 5;
        x.viTriDo = -1;
        processCheckIn(x, &HT, &Q, &G, &PQ, maxAllowed);
        flushPrintfToLog();
    }
    updateStatusLabels();
}

void runScenario7() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 7] CHECK-OUT VÀ TỰ ĐỘNG GỌI XE TỪ HÀNG ĐỜI QUEUE\r\n");
    appendLogU("=========================================================\r\n");
    Xe* pXe = NULL;
    for (int i = 0; i < HASH_SIZE; i++) {
        if (HT.buckets[i]) { pXe = &(HT.buckets[i]->xe); break; }
    }
    if (pXe) {
        processCheckOut(pXe->maThe, 630, 2.0f, &HT, &G, &Q, &PQ, maxAllowed);
        flushPrintfToLog();
    } else {
        appendLogU("[LỖI] Hiện bãi xe trống, không có xe nào để Check-out!\r\n");
    }
    updateStatusLabels();
}

void runScenario8() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 8] KIỂM THỬ LỖI TRÙNG BIỂN SỐ / TRÙNG MÃ THẺ\r\n");
    appendLogU("=========================================================\r\n");
    Xe x1 = {"CARD_DUPE", "59F1-DUPE", 0, 480, -1};
    processCheckIn(x1, &HT, &Q, &G, &PQ, maxAllowed);
    flushPrintfToLog();

    appendLogU("\r\n>>> THỬ QUẸT TRÙNG MÃ THẺ 'CARD_DUPE' <<<\r\n");
    Xe x2 = {"CARD_DUPE", "59F1-OTHER", 0, 490, -1};
    int res = processCheckIn(x2, &HT, &Q, &G, &PQ, maxAllowed);
    flushPrintfToLog();
    if (res == -2) {
        MessageBoxW(hMainWnd, L"[LỖI TỒN TẠI] Trùng Mã Thẻ: Mã thẻ 'CARD_DUPE' đã có xe đỗ trong bãi!", L"Lỗi Trùng Mã Thẻ", MB_OK | MB_ICONERROR);
    }
    updateStatusLabels();
}

void runScenario9() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 9] KIỂM THỬ TÌM KIẾM CHÍNH XÁC VÀ TÌM MỜ LEVENSHTEIN\r\n");
    appendLogU("=========================================================\r\n");
    SetTextU(hSearchKey, "59F1-10001");
    onSearch();
}

void runScenario10() {
    appendLogU("\r\n=========================================================\r\n");
    appendLogU("[KỊCH BẢN 10] KHỞI TẠO LẠI / XÓA SẠCH TOÀN BỘ BÃI XE\r\n");
    appendLogU("=========================================================\r\n");
    initHashTable(&HT);
    initQueue(&Q);
    initPQ(&PQ, 50);
    initStack(&S);
    for (int i = 0; i < G.n; i++) G.isOccupied[i] = 0;
    G.isOccupied[0] = 1;
    maxAllowed = physicalCapacity;
    activePathLen = 0;
    selectedSlot = -1;
    appendLogU("[HỆ THỐNG] Đã dọn sạch toàn bộ bãi xe về trạng thái ban đầu (0 xe).\r\n");
    updateStatusLabels();
}

BOOL CALLBACK SetFontProc(HWND hwnd, LPARAM lParam) {
    SendMessageW(hwnd, WM_SETFONT, (WPARAM)lParam, TRUE);
    return TRUE;
}

// ---------------------------------------------------------------------------
// MAIN WINDOW PROCEDURE
// ---------------------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    switch (msg) {
    case WM_CREATE: {
        HFONT hFont = CreateFontW(14, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, L"Segoe UI");

        // TOP HEADER STATUS PANEL
        hGroupStatus = CreateControlU("BUTTON", "Trạng Thái Hệ Thống Bãi Xe", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);
        hLblCount = CreateControlU("STATIC", "Đang đỗ: 0 / 300 xe", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)IDC_LBL_COUNT);
        hLblLimit = CreateControlU("STATIC", "Giới hạn SV: 300 xe", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)IDC_LBL_LIMIT);
        hLblQueue = CreateControlU("STATIC", "Hàng chờ ở cổng: 0 xe", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)IDC_LBL_QUEUE);
        hLblHeap  = CreateControlU("STATIC", "Xe SV đỗ ké (Heap): 0 xe", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)IDC_LBL_HEAP);

        // LEFT COLUMN: 2D MAP CANVAS & LOG / HASH TABLE
        hGroupMap = CreateControlU("BUTTON", "Sơ Đồ Bãi Xe & Dẫn Đường 2D (Tương tác Click chọn Ô Đỗ)", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);

        WNDCLASSEXW wmc = { 0 };
        wmc.cbSize = sizeof(WNDCLASSEXW);
        wmc.lpfnWndProc = MapCanvasWndProc;
        wmc.hInstance = GetModuleHandle(NULL);
        wmc.hCursor = LoadCursor(NULL, IDC_HAND);
        wmc.lpszClassName = L"ParkingLotMapCanvas_v7";
        RegisterClassExW(&wmc);

        hMapCanvas = CreateWindowExW(0, L"ParkingLotMapCanvas_v7", L"",
            WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, (HMENU)IDC_MAP_CANVAS, GetModuleHandle(NULL), NULL);

        hGroupLog = CreateControlU("BUTTON", "Nhật Ký Vận Hành & Lộ Trình Dijkstra", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);
        hLogBox = CreateControlU("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL | ES_READONLY, 0, 0, 0, 0, hwnd, (HMENU)IDC_LOG_BOX);

        hGroupHash = CreateControlU("BUTTON", "Bảng Băm Hash Table (101 Buckets)", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);
        hHashBox = CreateControlU("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL | ES_READONLY | ES_AUTOHSCROLL | WS_HSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_HASH_BOX);

        hGroupQueue = CreateControlU("BUTTON", "Cột Hàng Đợi Queue (Chờ ở cổng)", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);
        hQueueBox = CreateControlU("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | ES_AUTOVSCROLL | WS_VSCROLL | ES_READONLY | ES_AUTOHSCROLL | WS_HSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_QUEUE_BOX);

        // RIGHT COLUMN: CONTROL PANELS & 10 QUICK SCENARIO BUTTONS
        // Check-In Panel
        hGroupIn = CreateControlU("BUTTON", "1. Quẹt Thẻ Vào (Check-In)", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);
        hInCardLbl = CreateControlU("STATIC", "Mã thẻ:", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, NULL);
        hInCard = CreateControlU("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_IN_CARD);

        hInPlateLbl = CreateControlU("STATIC", "Biển số:", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, NULL);
        hInPlate = CreateControlU("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_IN_PLATE);

        hInTypeLbl = CreateControlU("STATIC", "Đối tượng:", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, NULL);
        hInType = CreateControlU("COMBOBOX", "", WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_IN_TYPE);
        SendMessageW(hInType, CB_ADDSTRING, 0, (LPARAM)U("Sinh Viên"));
        SendMessageW(hInType, CB_ADDSTRING, 0, (LPARAM)U("Giảng Viên"));
        SendMessageW(hInType, CB_SETCURSEL, 0, 0);

        hInTimeLbl = CreateControlU("STATIC", "Giờ vào:", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, NULL);
        hInTime = CreateControlU("EDIT", "08:00", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_IN_TIME);

        hBtnCheckIn = CreateControlU("BUTTON", "QUẸT THẺ VÀO (IN)", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_BTN_CHECKIN);

        // Check-Out Panel
        hGroupOut = CreateControlU("BUTTON", "2. Quẹt Thẻ Ra (Check-Out)", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);
        hOutQueryLbl = CreateControlU("STATIC", "Mã thẻ / Biển số:", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, NULL);
        hOutQuery = CreateControlU("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_OUT_QUERY);

        hOutTimeLbl = CreateControlU("STATIC", "Giờ ra (HH:MM):", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, NULL);
        hOutTime = CreateControlU("EDIT", "10:30", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_OUT_TIME);

        hBtnCheckOut = CreateControlU("BUTTON", "QUẸT THẺ RA (OUT)", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_BTN_CHECKOUT);

        // Operations Panel
        hGroupSearch = CreateControlU("BUTTON", "3. Tìm Kiếm & Giới Hạn", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);
        hSearchKeyLbl = CreateControlU("STATIC", "Từ khóa tìm:", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, NULL);
        hSearchKey = CreateControlU("EDIT", "", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_SEARCH_KEY);
        hBtnSearch = CreateControlU("BUTTON", "TÌM KIẾM", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_BTN_SEARCH);

        hNewLimitLbl = CreateControlU("STATIC", "Giới hạn đỗ SV:", WS_CHILD | WS_VISIBLE, 0, 0, 0, 0, hwnd, NULL);
        hNewLimit = CreateControlU("EDIT", "250", WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL, 0, 0, 0, 0, hwnd, (HMENU)IDC_NEW_LIMIT);
        hBtnLimit = CreateControlU("BUTTON", "ĐỔI GIỚI HẠN", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_BTN_LIMIT);
        hBtnEvict = CreateControlU("BUTTON", "DI DỜI SV", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_BTN_EVICT);

        // 10 QUICK-TEST SCENARIOS GROUPBOX
        hGroupScenarios = CreateControlU("BUTTON", "4. 10 Kịch Bản Kiểm Thử Nhanh (Click Chạy Ngay)", WS_CHILD | WS_VISIBLE | BS_GROUPBOX, 0, 0, 0, 0, hwnd, NULL);

        hBtnScenario[0] = CreateControlU("BUTTON", "[1] Lấp Đầy Khu SV (200 ô)", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_1);
        hBtnScenario[1] = CreateControlU("BUTTON", "[2] Lấp Đầy Khu GV (100 ô)", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_2);
        hBtnScenario[2] = CreateControlU("BUTTON", "[3] Bãi Đầy 100% (300/300)", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_3);
        hBtnScenario[3] = CreateControlU("BUTTON", "[4] Test Xe thứ 11 Đỗ Ké", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_4);
        hBtnScenario[4] = CreateControlU("BUTTON", "[5] Di Dời Xe SV (Heap/Stack)", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_5);
        hBtnScenario[5] = CreateControlU("BUTTON", "[6] Hàng Đợi Queue FIFO", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_6);
        hBtnScenario[6] = CreateControlU("BUTTON", "[7] Check-Out & Gọi Queue", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_7);
        hBtnScenario[7] = CreateControlU("BUTTON", "[8] Test Lỗi Trùng Mã/Biển", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_8);
        hBtnScenario[8] = CreateControlU("BUTTON", "[9] Test Tìm Kiếm Mờ", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_9);
        hBtnScenario[9] = CreateControlU("BUTTON", "[10] Reset Sạch Bãi Xe", WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0, hwnd, (HMENU)IDC_SCENARIO_10);

        EnumChildWindows(hwnd, SetFontProc, (LPARAM)hFont);

        loadMapFromFile("map.txt", &G);
        initHashTable(&HT);
        initQueue(&Q);
        initPQ(&PQ, 50);
        initStack(&S);
        physicalCapacity = G.n - 1;
        maxAllowed = physicalCapacity;

        setupStdoutPipe();
        updateStatusLabels();

        appendLogU("=========================================================================================\r\n");
        appendLogU("   HỆ THỐNG QUẢN LÝ BÃI GIỮ XE (Tích Hợp 10 Nút Kịch Bản Kiểm Thử Tự Động)\r\n");
        appendLogU("=========================================================================================\r\n");
        appendLogU("[KHỞI TẠO] Nạp bản đồ map.txt thành công (Đồ thị 301 đỉnh, 300 ô đỗ).\r\n");
        appendLogU("[HƯỚNG DẪN] Bấm trực tiếp các Nút kịch bản [1] -> [10] góc dưới bên phải để mô phỏng tức thì!\r\n\r\n");

        return 0;
    }
    case WM_SIZE: {
        int w = LOWORD(lParam);
        int h = HIWORD(lParam);
        layoutControls(w, h);
        return 0;
    }
    case WM_COMMAND: {
        int id = LOWORD(wParam);
        switch (id) {
        case IDC_BTN_CHECKIN:  onCheckIn(); break;
        case IDC_BTN_CHECKOUT: onCheckOut(); break;
        case IDC_BTN_SEARCH:   onSearch(); break;
        case IDC_BTN_EVICT:    onEvict(); break;
        case IDC_BTN_LIMIT:    onSetLimit(); break;

        case IDC_SCENARIO_1:   runScenario1(); break;
        case IDC_SCENARIO_2:   runScenario2(); break;
        case IDC_SCENARIO_3:   runScenario3(); break;
        case IDC_SCENARIO_4:   runScenario4(); break;
        case IDC_SCENARIO_5:   runScenario5(); break;
        case IDC_SCENARIO_6:   runScenario6(); break;
        case IDC_SCENARIO_7:   runScenario7(); break;
        case IDC_SCENARIO_8:   runScenario8(); break;
        case IDC_SCENARIO_9:   runScenario9(); break;
        case IDC_SCENARIO_10:  runScenario10(); break;
        }
        break;
    }
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    WNDCLASSEXW wc = { 0 };
    wc.cbSize = sizeof(WNDCLASSEXW);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInstance;
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_BTNFACE + 1);
    wc.lpszClassName = L"SmartParkingWin32GUI_v8";

    if (!RegisterClassExW(&wc)) {
        MessageBoxW(NULL, L"Lỗi đăng ký lớp cửa sổ Win32 Unicode!", L"Lỗi", MB_ICONERROR);
        return 0;
    }

    hMainWnd = CreateWindowExW(0, L"SmartParkingWin32GUI_v8",
        L"Hệ thống quản lý bãi giữ xe",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 1360, 785,
        NULL, NULL, hInstance, NULL);

    if (!hMainWnd) return 0;

    ShowWindow(hMainWnd, SW_SHOWMAXIMIZED);
    UpdateWindow(hMainWnd);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }
    return (int)msg.wParam;
}
