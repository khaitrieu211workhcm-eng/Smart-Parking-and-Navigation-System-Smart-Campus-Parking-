#include "DataStructures.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// ==========================================
// HASH TABLE (SEPARATE CHAINING)
// ==========================================
unsigned int hashFunction(char* key) {
    unsigned int hash = 0;
    for (int i = 0; key[i] != '\0'; i++) {
        hash = hash * 31 + key[i];
    }
    return hash % HASH_SIZE;
}

void initHashTable(HashTable* HT) {
    for (int i = 0; i < HASH_SIZE; i++) {
        HT->buckets[i] = NULL;
    }
}

void insertHash(HashTable* HT, Xe xe) {
    unsigned int idx = hashFunction(xe.maThe);
    HashNode* newNode = (HashNode*)malloc(sizeof(HashNode));
    newNode->xe = xe;
    newNode->next = HT->buckets[idx];
    HT->buckets[idx] = newNode;
}

Xe* searchHash(HashTable* HT, char* maThe) {
    unsigned int idx = hashFunction(maThe);
    HashNode* curr = HT->buckets[idx];
    while (curr != NULL) {
        if (strcmp(curr->xe.maThe, maThe) == 0) {
            return &(curr->xe);
        }
        curr = curr->next;
    }
    return NULL;
}

void removeHash(HashTable* HT, char* maThe) {
    unsigned int idx = hashFunction(maThe);
    HashNode* curr = HT->buckets[idx];
    HashNode* prev = NULL;
    while (curr != NULL) {
        if (strcmp(curr->xe.maThe, maThe) == 0) {
            if (prev == NULL) {
                HT->buckets[idx] = curr->next;
            }
            else {
                prev->next = curr->next;
            }
            free(curr);
            return;
        }
        prev = curr;
        curr = curr->next;
    }
}

// ==========================================
// QUEUE (FIFO - LINKED LIST BASED)
// ==========================================
void initQueue(Queue* Q) {
    Q->front = Q->rear = NULL;
}

int isEmptyQueue(Queue* Q) {
    return Q->front == NULL;
}

void EnQueue(Queue* Q, Xe xe) {
    QueueNode* newNode = (QueueNode*)malloc(sizeof(QueueNode));
    newNode->xe = xe;
    newNode->next = NULL;
    if (Q->rear == NULL) {
        Q->front = Q->rear = newNode;
        return;
    }
    Q->rear->next = newNode;
    Q->rear = newNode;
}

int DeQueue(Queue* Q, Xe* resXe) {
    if (isEmptyQueue(Q)) return 0;
    QueueNode* temp = Q->front;
    *resXe = temp->xe;
    Q->front = Q->front->next;
    if (Q->front == NULL) {
        Q->rear = NULL;
    }
    free(temp);
    return 1;
}

// ==========================================
// STACK (LIFO - LINKED LIST BASED)
// ==========================================
void initStack(Stack* S) {
    S->top = NULL;
}

int isEmptyStack(Stack* S) {
    return S->top == NULL;
}

void Push(Stack* S, Xe xe) {
    StackNode* newNode = (StackNode*)malloc(sizeof(StackNode));
    newNode->xe = xe;
    newNode->next = S->top;
    S->top = newNode;
}

Xe Pop(Stack* S) {
    if (isEmptyStack(S)) {
        Xe empty = { 0 };
        return empty;
    }
    StackNode* temp = S->top;
    Xe poppedXe = temp->xe;
    S->top = S->top->next;
    free(temp);
    return poppedXe;
}

// ==========================================
// PRIORITY QUEUE (MIN-HEAP THEO THOI GIAN VAO)
// ==========================================
void initPQ(PriorityQueue* PQ, int capacity) {
    PQ->capacity = capacity;
    PQ->size = 0;
    PQ->heap = (Xe*)malloc(capacity * sizeof(Xe));
}

void swapXe(Xe* x, Xe* y) {
    Xe temp = *x;
    *x = *y;
    *y = temp;
}

void pushPQ(PriorityQueue* PQ, Xe xe) {
    if (PQ->size == PQ->capacity) {
        PQ->capacity *= 2;
        PQ->heap = (Xe*)realloc(PQ->heap, PQ->capacity * sizeof(Xe));
    }
    PQ->heap[PQ->size] = xe;
    int i = PQ->size;
    PQ->size++;

    // Heapify up
    while (i != 0 && PQ->heap[(i - 1) / 2].thoiGianVao > PQ->heap[i].thoiGianVao) {
        swapXe(&PQ->heap[i], &PQ->heap[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

Xe popPQ(PriorityQueue* PQ) {
    if (PQ->size <= 0) {
        Xe empty = { 0 };
        return empty;
    }
    if (PQ->size == 1) {
        PQ->size--;
        return PQ->heap[0];
    }

    Xe root = PQ->heap[0];
    PQ->heap[0] = PQ->heap[PQ->size - 1];
    PQ->size--;

    // Heapify down
    int i = 0;
    while (2 * i + 1 < PQ->size) {
        int left = 2 * i + 1;
        int right = 2 * i + 2;
        int smallest = left;

        if (right < PQ->size && PQ->heap[right].thoiGianVao < PQ->heap[left].thoiGianVao) {
            smallest = right;
        }
        if (PQ->heap[i].thoiGianVao <= PQ->heap[smallest].thoiGianVao) {
            break;
        }
        swapXe(&PQ->heap[i], &PQ->heap[smallest]);
        i = smallest;
    }

    return root;
}