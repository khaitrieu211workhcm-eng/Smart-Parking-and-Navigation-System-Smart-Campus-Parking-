#define _CRT_SECURE_NO_WARNINGS
#include "CheckOut.h"
#include "CheckIn.h"
#include <stdio.h>
#include <string.h>

// Tim xe trong bai bang ma the hoac bien so
Xe* findCarInParking(HashTable* HT, char* query) {
    // 1. Tim theo ma the
    Xe* xe = searchHash(HT, query);
    if (xe != NULL) return xe;

    // 2. Tim theo bien so (bo dau cach, gach noi, chuyen hoa)
    for (int i = 0; i < HASH_SIZE; i++) {
        HashNode* curr = HT->buckets[i];
        while (curr != NULL) {
            char n1[50]={0}, n2[50]={0};
            int l1=0, l2=0;
            for (int k=0; curr->xe.bienSo[k]; k++) {
                char c = curr->xe.bienSo[k];
                if (c!=' '&&c!='-'&&c!='.') { if(c>='a'&&c<='z') c-=32; n1[l1++]=c; }
            }
            for (int k=0; query[k]; k++) {
                char c = query[k];
                if (c!=' '&&c!='-'&&c!='.') { if(c>='a'&&c<='z') c-=32; n2[l2++]=c; }
            }
            if (strcmp(n1, n2) == 0) return &(curr->xe);
            curr = curr->next;
        }
    }
    return NULL;
}

// Xu ly check-out: Tim xe -> Tinh tien -> Giai phong -> Goi xe tu hang doi
float processCheckOut(char* query, int thoiGianRa, float donGia, HashTable* HT, Graph* G, Queue* Q, PriorityQueue* PQ, int maxAllowed) {
    Xe* outXe = findCarInParking(HT, query);
    if (!outXe) { printf("Khong tim thay xe %s!\n", query); return -1.0; }

    float cost = (thoiGianRa - outXe->thoiGianVao) * donGia;
    printf("Xe %s (%s) ra. O %d. %d phut. %.0f VND.\n",
           outXe->bienSo, outXe->isGiangVien?"GV":"SV",
           outXe->viTriDo, thoiGianRa - outXe->thoiGianVao, cost);

    G->isOccupied[outXe->viTriDo] = 0;
    char card[20]; strcpy(card, outXe->maThe);
    removeHash(HT, card);

    // Goi xe tu hang doi (GV luon duoc vao, SV phai duoi gioi han)
    if (!isEmptyQueue(Q) && getCurrentCarCount(HT) < maxAllowed) {
        Xe next;
        if (DeQueue(Q, &next)) {
            printf("\n--- SỰ KIỆN CHECK-IN (TỰ ĐỘNG TỪ HÀNG ĐỜI QUEUE): Thẻ [%s] | Biển số [%s] | Đối tượng [%s] | Giờ vào %02dh%02d ---\n",
                   next.maThe, next.bienSo,
                   next.isGiangVien ? "Giảng Viên" : "Sinh Viên",
                   next.thoiGianVao / 60, next.thoiGianVao % 60);
            int slot = processCheckIn(next, HT, Q, G, PQ, maxAllowed);
            if (slot >= 0) {
                printf("=> Kết quả: Xe [%s] từ Hàng đợi đã vào bãi THÀNH CÔNG --- vào ô số %d\n", next.bienSo, slot);
            }
        }
    }
    return cost;
}