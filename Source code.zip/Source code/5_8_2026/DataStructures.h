#pragma once
#ifndef DATA_STRUCTURES_H
#define DATA_STRUCTURES_H

#define MAX_NODES 305
#define HASH_SIZE 101

// Cau truc thong tin chiec xe
typedef struct {
    char maThe[20];
    char bienSo[20];
    int isGiangVien; // 1: Giang vien, 0: Sinh vien
    int thoiGianVao; // Quy doi ra phut tu dau ngay
    int viTriDo;     // ID cua dinh tren do thi
} Xe;

// Cau truc Do thi bai xe
typedef struct {
    int n; // So luong dinh
    int zoneType[MAX_NODES]; // -1: Cong, 1: Khu GV, 0: Khu SV
    int isOccupied[MAX_NODES]; // 1: Da co xe, 0: Trong
    int matrix[MAX_NODES][MAX_NODES]; // Ma tran ke khoang cach
} Graph;

// Cau truc Node cho Bang bam (Separate Chaining)
typedef struct HashNode {
    Xe xe;
    struct HashNode* next;
} HashNode;

typedef struct {
    HashNode* buckets[HASH_SIZE];
} HashTable;

// Cau truc Node cho Hang doi doi o cong (Queue)
typedef struct QueueNode {
    Xe xe;
    struct QueueNode* next;
} QueueNode;

typedef struct {
    QueueNode* front;
    QueueNode* rear;
} Queue;

// Cau truc Node cho Ngan xep di doi xe (Stack)
typedef struct StackNode {
    Xe xe;
    struct StackNode* next;
} StackNode;

typedef struct {
    StackNode* top;
} Stack;

// Cau truc Hang doi uu tien (Min-Heap theo thoi gian vao)
typedef struct {
    Xe* heap;
    int size;
    int capacity;
} PriorityQueue;

// Khai bao cac ham khoi tao va thao tac voi CTDL
void initHashTable(HashTable* HT);
void insertHash(HashTable* HT, Xe xe);
Xe* searchHash(HashTable* HT, char* maThe);
void removeHash(HashTable* HT, char* maThe);

void initQueue(Queue* Q);
int isEmptyQueue(Queue* Q);
void EnQueue(Queue* Q, Xe xe);
int DeQueue(Queue* Q, Xe* resXe);

void initStack(Stack* S);
int isEmptyStack(Stack* S);
void Push(Stack* S, Xe xe);
Xe Pop(Stack* S);

void initPQ(PriorityQueue* PQ, int capacity);
void pushPQ(PriorityQueue* PQ, Xe xe);
Xe popPQ(PriorityQueue* PQ);

#endif // DATA_STRUCTURES_H