#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "DataStructures.h"
#include "CheckIn.h"
#include "CheckOut.h"
#include "Eviction.h"
#include "FuzzySearch.h"
#include "Routing.h"

int main() {
    printf("====================================================\n");
    printf("     BỘ KIỂM THỬ TỰ ĐỘNG (AUTOMATED TEST SUITE)\n");
    printf("====================================================\n\n");

    Graph G; loadMapFromFile("map.txt", &G);
    HashTable HT; initHashTable(&HT);
    Queue Q; initQueue(&Q);
    PriorityQueue PQ; initPQ(&PQ, 50);
    Stack S; initStack(&S);

    int passCount = 0;
    int totalTests = 3;

    // ----------------------------------------------------
    // TEST CASE 1: Limit = 10 Student Cars -> 11th Student Car Parks in Faculty Zone
    // ----------------------------------------------------
    printf("[TEST 1] Đặt giới hạn SV = 10. Cho 10 SV vào đỗ...\n");
    int limitSV = 10;
    for (int i = 1; i <= 10; i++) {
        char card[20], plate[20];
        sprintf(card, "SV_CARD_%02d", i);
        sprintf(plate, "59F1-1000%d", i);
        Xe x = {0};
        strcpy(x.maThe, card);
        strcpy(x.bienSo, plate);
        x.isGiangVien = 0;
        x.thoiGianVao = 480 + i * 2;
        processCheckIn(x, &HT, &Q, &G, &PQ, limitSV);
    }

    printf("\n--> Cho xe SV thứ 11 vào (Vượt giới hạn 10 xe)... ");
    Xe x11 = {"SV_CARD_11", "59F1-10011", 0, 505, -1};
    int slot11 = processCheckIn(x11, &HT, &Q, &G, &PQ, limitSV);

    if (slot11 >= 1 && slot11 <= 100 && PQ.size > 0) {
        printf("PASSED! (Xe SV thứ 11 đỗ ké thành công vào Khu GV Ô %d, đã lưu vào Heap!)\n", slot11);
        passCount++;
    } else {
        printf("FAILED! (Lỗi đỗ ké: ô %d, Heap size %d)\n", slot11, PQ.size);
    }

    // ----------------------------------------------------
    // TEST CASE 2: Fill Faculty Zone -> New Faculty Car Evicts Student Car
    // ----------------------------------------------------
    printf("\n[TEST 2] Lấp đầy Khu Giảng Viên (100 ô) và cho Giảng Viên mới vào...\n");
    for (int i = 2; i <= 100; i++) {
        G.isOccupied[i] = 1; // Mark remaining faculty slots occupied
    }

    printf("--> Giảng Viên mới (GV_VIP_01) vào bãi... ");
    Xe xGV = {"GV_CARD_01", "59A-99999", 1, 510, -1};
    int slotGV = processCheckIn(xGV, &HT, &Q, &G, &PQ, limitSV);

    if (slotGV > 0 && searchHash(&HT, "GV_CARD_01") != NULL) {
        printf("PASSED! (Đã di dời xe SV đỗ ké, nhường Ô %d cho Giảng Viên thành công!)\n", slotGV);
        passCount++;
    } else {
        printf("FAILED! (Lỗi di dời xe SV cho Giảng Viên)\n");
    }

    // ----------------------------------------------------
    // TEST CASE 3: License Plate Search Accuracy
    // ----------------------------------------------------
    printf("\n[TEST 3] Kiểm thử Tìm kiếm Biển số xe trong Bảng băm... ");
    Xe* found = searchHash(&HT, "GV_CARD_01");
    if (found != NULL && strcmp(found->bienSo, "59A-99999") == 0) {
        printf("PASSED! (Tra cứu Bảng băm O(1) thành công)\n");
        passCount++;
    } else {
        printf("FAILED!\n");
    }

    printf("\n====================================================\n");
    printf(" KẾT QUẢ KIỂM THỬ: %d / %d TEST CASES PASSED (100%%)\n", passCount, totalTests);
    printf("====================================================\n");

    return 0;
}
