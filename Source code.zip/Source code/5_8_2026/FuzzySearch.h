#pragma once
#ifndef FUZZYSEARCH_H
#define FUZZYSEARCH_H

#include "DataStructures.h"

#ifndef INF
#define INF 999999
#endif

typedef struct {
    Xe xe;
    int score;
} FuzzyResult;

void normalizeString(char* src, char* dst);
int getLevenshteinDistance(char* s1, char* s2);
Xe* fuzzySearchLicensePlate(HashTable* HT, char* queryPlate, int* resultCount);

#endif // FUZZYSEARCH_H