#pragma once
#ifndef CHECKIN_H
#define CHECKIN_H

#include "DataStructures.h"

int getCurrentCarCount(HashTable* HT);
int processCheckIn(Xe newXe, HashTable* HT, Queue* Q, Graph* G, PriorityQueue* PQ, int maxAllowed);
void runSimulationFromConsole(HashTable* HT, Queue* Q, Graph* G, PriorityQueue* PQ, int maxAllowed);

#endif // CHECKIN_H