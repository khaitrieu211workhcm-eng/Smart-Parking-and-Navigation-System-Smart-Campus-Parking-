#pragma once
#ifndef CHECKOUT_H
#define CHECKOUT_H

#include "DataStructures.h"

float processCheckOut(char* maThe, int thoiGianRa, float donGia, HashTable* HT, Graph* G, Queue* Q, PriorityQueue* PQ, int maxAllowed);

#endif // CHECKOUT_H